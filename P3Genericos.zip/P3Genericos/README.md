# README

## Explicacion Del Codigo:

El codigo esta explicado en comentarios dentro del codigo

## Dificultades

Me ha costado bastante entender la estructura de los metodos generales en el primer ejercicio y al existir ya metodos importados desde LinkedList con los mismos nombres me confundio un poco.

En el segundo ejercicio me costo crear el metodo add ya que no supe como expandir el limite de espacio del array.

## Funcionalidades no conseguidas

Todas las funcionalidades han sido conseguidas y he podido hacer que se expanda el array si se introducen mas elementos del limite establecido inicialmente

## Porque he usado un LinkedList

He usado el LinkedList ya que es mejor que el ArrayList en cuanto manipulacion de datos ademas al usar LinkedList al borrar el primer elemento el segundo elemento toma el lugar del primero.

### PD

En el enunciado pone que debemos entregar los ejercicios en el formato GIF pero no se como crear un GIF asi que he usado capturas de pantalla.

